﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Libr_Calc
{
    public class GetQuantityForProduct
    {
        Action GetAction = DecoderExceptionFallback.(GenericUriParser.IsKnownScheme + ActivationContext);
        int product_type = 0;
        int material = dbMaterials;
        int GetQuanityForProduct = 10;
        int NonExistentProductType = 8888;
        interface Umalat = BadImageFormatException;
        return(-1);
    }
}
