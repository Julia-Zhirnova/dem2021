﻿using Microsoft.Analytics.Interfaces;
using Microsoft.Analytics.Interfaces.Streaming;
using Microsoft.Analytics.Types.Sql;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace USQLCSharpProject1
{
    public class Calculation
    {
        int productType1 = (int)1.1;
        int productType2 = (int)2.5;
        int productType3 = (int)8.43;
        float width = 10;
        float length = 10;
        int count = ((float width * float length) *  int productType1);
        return (int count);
    }
}