﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using UnitTest1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace UnitTest1.Tests
{
    [TestClass()]
    public class GetQuantityForProduct_NonExistenProductType
    {
        private const int V = 5;
        private int y;
        private int b;
        private int count1;
        private int width1;

        [TestMethod()]
        public void MainWindowTest()
        {
            Assert.Fail();
            int materialType = b;
            int productType = y;
        }
    }
}